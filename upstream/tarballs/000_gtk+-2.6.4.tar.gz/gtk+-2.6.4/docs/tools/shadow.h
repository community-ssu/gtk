#ifndef __SHADOW_H__
#define __SHADOW_H__

#include <gdk-pixbuf/gdk-pixbuf.h>

GdkPixbuf *create_shadowed_pixbuf (GdkPixbuf *src);

#endif /* __SHADOW_H__ */
