const char *mversion="3.9.10";
const char *mdate = "March 2nd, 2005";
